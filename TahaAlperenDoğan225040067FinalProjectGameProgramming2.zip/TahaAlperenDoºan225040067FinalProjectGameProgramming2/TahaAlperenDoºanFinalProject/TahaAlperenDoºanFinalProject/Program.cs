﻿using System;
using System.Collections.Generic;
using System.Threading;

class Program
{
    static int mapWidth = 40; // Harita genişliği iki katına çıkarıldı
    static int mapHeight = 20; // Harita yüksekliği iki katına çıkarıldı
    static char[,] map = new char[mapHeight, mapWidth];
    static int caravanX = 0;
    static int caravanY = 0;
    static int money = 1000;
    static int soldiers = 10;
    static int hours = 8; // Günü saat 8:00'de başlatalım
    static int minutes = 0;
    static List<(int x, int y)> enemies = new List<(int x, int y)>();

    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        ShowTitleScreen();
        ShowStory();
        InitializeMap();
        PlayGame();
    }

    static void ShowTitleScreen()
    {
        Console.Clear();
        Console.WriteLine("\r\n███████████████████████████████████████████████████████████████████████████████\r\n█─▄▄▄─██▀▄─██▄─▀█▀─▄█▄─▄▄─█▄─▄█████─▄▄▄─██▀▄─██▄─▄▄▀██▀▄─██▄─█─▄██▀▄─██▄─▀█▄─▄█\r\n█─███▀██─▀─███─█▄█─███─▄█▀██─██▀███─███▀██─▀─███─▄─▄██─▀─███▄▀▄███─▀─███─█▄▀─██\r\n▀▄▄▄▄▄▀▄▄▀▄▄▀▄▄▄▀▄▄▄▀▄▄▄▄▄▀▄▄▄▄▄▀▀▀▄▄▄▄▄▀▄▄▀▄▄▀▄▄▀▄▄▀▄▄▀▄▄▀▀▀▄▀▀▀▄▄▀▄▄▀▄▄▄▀▀▄▄▀\r\n██████████████████████████████████████████████████████████\r\n██▀▄─██▄─▄▄▀█▄─█─▄█▄─▄▄─█▄─▀█▄─▄█─▄─▄─█▄─██─▄█▄─▄▄▀█▄─▄▄─█\r\n██─▀─███─██─██▄▀▄███─▄█▀██─█▄▀─████─████─██─███─▄─▄██─▄█▀█\r\n▀▄▄▀▄▄▀▄▄▄▄▀▀▀▀▄▀▀▀▄▄▄▄▄▀▄▄▄▀▀▄▄▀▀▄▄▄▀▀▀▄▄▄▄▀▀▄▄▀▄▄▀▄▄▄▄▄▀");
        Console.WriteLine("░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\r\n░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\r\n░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\r\n░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\r\n░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\r\n░░░░░░░░█░░░░░░░░░░░░░░░░░░░░░░░░░░█░░░░░░░░░░░░░░░░░░░░░░░░░░█░░░░░░░░░░░░░░░░░░░░\r\n░░░░░████░░░░░░░░░░░░░░░░░░░░░░░████░░░░░░░░░░░░░░░░░░░░░░░████░░░░░░░░░░░░░░░░░░░░\r\n░░░██████░░░░███░░░░██░░░░░░░░██████░░░░███░░░░██░░░░░░░░██████░░░░███░░░░██░░░░░░░\r\n░░░░░░░█▄▄░██████░█████░░░░░░░░░▄▄██░░██████░█████░░░░░░░░░░░██░░██████░█████░░░░░░\r\n░░░░░░░██░▀▄▄▄▄█████████▄▄▄▄█▀▀▀░░██▀█▄▄▄██████████░█░░░░▄▄█▀██░██████████████░█░░░\r\n░░░░░░░████████▀▀▀▀▀▀▀▀▀█░░░░░░░░░███████▀▀▀▀▀▀▄▄▄▄▄▄█▀▀▀░░░░██████████████████░░░░\r\n░░░░░░░██████████████████░░░░░░░░░██████████████████░░░░░░░░░██████████████████░░░░\r\n░░░░░░░░░██████████████░░░░░░░░░░░░░██████████████░░░░░░░░░░░░░██████████████░░░░░░\r\n░░░░░░░░░░░██░░██░░████░░░░░░░░░░░░░░░██░░██░░████░░░░░░░░░░░░░░░██░░██░░████░░░░░░\r\n░░░░░░░░░░░██░░██░░████░░░░░░░░░░░░░░░██░░██░░████░░░░░░░░░░░░░░░██░░██░░████░░░░░░\r\n░░░░░░░░░░░██░░██░░░░██░░░░░░░░░░░░░░░██░░██░░░░██░░░░░░░░░░░░░░░██░░██░░░░██░░░░░░\r\n░░░░░░░░░░░██░░██░░░░██░░░░░░░░░░░░░░░██░░██░░░░██░░░░░░░░░░░░░░░██░░██░░░░██░░░░░░\r\n░░░░░░░░░░░██░░██░░░░██░░░░░░░░░░░░░░░██░░██░░░░██░░░░░░░░░░░░░░░██░░██░░░░██░░░░░░\r\n░░░░░░░░░░░██░░██░░████░░░░░░░░░░░░░░░██░░██░░████░░░░░░░░░░░░░░░██░░██░░████░░░░░░\r\n░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\r\n░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\r\n");
        Console.WriteLine("\r\n█▀█ █▀█ █▀▀ █▀ █▀   ▄▀█ █▄░█ █▄█   █▄▀ █▀▀ █▄█   ▀█▀ █▀█   █▀ ▀█▀ ▄▀█ █▀█ ▀█▀\r\n█▀▀ █▀▄ ██▄ ▄█ ▄█   █▀█ █░▀█ ░█░   █░█ ██▄ ░█░   ░█░ █▄█   ▄█ ░█░ █▀█ █▀▄ ░█░");

        Console.ReadKey();
    }

    static void ShowStory()
    {
        Console.Clear();
        Console.WriteLine("░░░░░░░░░░░░░░  ░░░░░░                                                                                                        ░░░░░░░░░░░░░░░░░░░░\r\n░░░░                                                                                                          ░░░░▒▒        ░░░░    ░░░░░░░░░░░░░░\r\n░░░░                                                                    ░░▒▒                                  ░░░░▒▒▒▒          ░░░░░░░░░░░░░░░░░░\r\n░░░░░░░░                                                              ░░▒▒▓▓▓▓                              ░░░░░░▒▒▒▒▒▒    ░░░░░░░░░░░░░░░░░░░░░░\r\n░░░░░░░░                                                            ░░▒▒▒▒▓▓▓▓▒▒                        ░░░░░░░░▒▒▒▒▒▒▒▒▒▒░░  ░░░░░░░░░░░░░░░░░░░░\r\n░░░░░░░░░░                                                        ▒▒▒▒▒▒▒▒▓▓▒▒▒▒▓▓░░                    ░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░\r\n░░░░░░░░░░░░  ░░                                                ▒▒▒▒▒▒▒▒▓▓▒▒▓▓▒▒▒▒▒▒░░                ░░░░▒▒▒▒░░▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░\r\n░░░░░░░░░░░░░░                                                ▒▒▒▒▒▒▒▒▒▒▓▓▓▓▓▓▓▓▒▒▓▓▓▓▒▒            ░░░░░░░░░░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░░░\r\n░░░░░░░░░░░░░░░░                                            ▒▒▒▒▒▒▒▒▒▒▒▒▓▓▓▓▓▓▓▓▒▒▓▓▒▒▒▒▒▒░░    ░░░░░░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░\r\n░░░░░░░░░░░░░░░░░░░░░░                                    ▒▒▒▒▒▒▒▒▒▒▒▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▒▒  ░░▒▒░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░░░░░░░░░\r\n░░░░░░░░░░░░░░░░░░░░░░░░                              ░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓▒▒▓▓▓▓▓▓▓▓▓▓▒▒▒▒▓▓▒▒▒▒░░░░▒▒▒▒▒▒▒▒░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░░░░░░░\r\n░░░░░░░░░░░░░░░░░░░░░░░░░░  ░░                      ░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▒▒▓▓▓▓▒▒▒▒░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓░░░░░░░░░░░░\r\n░░░░░░░░░░░░░░░░░░░░░░░░░░▓▓▓▓              ░░    ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓▓▓▒▒▓▓▓▓▒▒▒▒▓▓▓▓▒▒▒▒▓▓▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓░░░░░░░░░░\r\n░░░░░░░░░░░░░░░░░░░░░░░░▒▒▒▒▓▓▓▓░░░░▒▒▒▒▒▒▒▒░░  ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓▓▓▒▒▓▓▓▓▒▒▓▓▒▒▓▓▒▒▒▒▒▒▓▓▒▒░░▒▒▒▒▒▒▒▒░░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓▓▓▒▒▒▒░░░░░░░░\r\n░░░░░░░░░░░░░░░░░░░░░░▒▒▒▒▒▒▓▓▓▓▓▓░░▒▒▒▒▓▓▓▓▒▒▒▒▒▒▒▒▒▒▓▓▓▓▒▒▒▒▒▒▒▒▒▒▒▒▓▓▓▓▓▓▒▒▓▓▓▓▒▒▓▓▓▓▒▒▒▒▓▓▓▓▓▓▓▓▒▒▒▒░░▒▒▒▒▒▒▒▒▓▓▓▓▒▒▒▒▓▓▒▒▒▒▒▒▒▒▒▒▓▓▓▓▒▒░░░░░░\r\n░░░░░░░░░░░░░░░░░░░░▒▒▓▓▓▓▓▓▓▓▓▓▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓▒▒▒▒▒▒▒▒▒▒▓▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒▒▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓▓▓▓▓░░░░\r\n░░░░░░░░░░░░░░░░▒▒▒▒▒▒▒▒▓▓▓▓▓▓▒▒▒▒▒▒▒▒▒▒▓▓▓▓▒▒▒▒▒▒▒▒▒▒▓▓▓▓▓▓▒▒▒▒▒▒▒▒▓▓▓▓▒▒▒▒▒▒▒▒▒▒▓▓▓▓▒▒▓▓▓▓▒▒▒▒▓▓▓▓▒▒▓▓▒▒░░▒▒▒▒▒▒▒▒▓▓▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓░░\r\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓▒▒▒▒▒▒▒▒▒▒▓▓▓▓▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒░░░░░░░░▒▒▒▒▒▒▒▒▒▒░░░░░░▒▒░░\r\n▒▒▒▒▒▒░░░░░░▒▒░░░░░░░░░░▒▒▒▒░░░░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓▓▓▓▓░░▒▒▒▒▒▒▒▒░░▒▒░░░░░░░░░░░░░░░░░░░░░░▒▒▒▒▒▒░░▒▒░░░░░░░░░░░░░░░░░░▒▒▒▒░░░░░░░░░░░░░░░░░░░░\r\n▒▒▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒░░▒▒░░▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒\r\n░░░░░░░░░░░░░░░░░░▒▒░░░░░░░░░░░░░░░░░░░░░░░░▒▒▒▒▒▒░░░░░░░░░░▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\r\n▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░▒▒░░▒▒▒▒▒▒▒▒▒▒▒▒░░▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒░░░░░░░░░░▒▒▒▒▒▒░░░░░░\r\n▒▒▒▒▒▒░░░░▒▒▒▒▒▒▒▒▒▒▒▒░░▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒░░░░░░░░\r\n▒▒▒▒▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\r\n▒▒▒▒▒▒▒▒▒▒░░▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒▒▒\r\n▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\r\n░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\r\n░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\r\n▒▒▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\r\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\r\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\r\n▒▒▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒░░░░░░▒▒▓▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\r\n▒▒▒▒▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▓▓██▓▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\r\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░██████░░▓▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\r\n▒▒▒▒▒▒▒▒▒▒▒▒░░▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░██▓▓▒▒▓▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒\r\n▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒▒▒░░░░▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒\r\n▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒▓▓▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒\r\n▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒▒▒░░▒▒▒▒░░░░░░░░░░░░▒▒▒▒▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒\r\n");
        Console.WriteLine("As the hot winds of the desert continue to torment the nomadic caravans fleeing from Pharaoh's tyranny, you emerge as a brave caravan leader. Fueled by anger against Pharaoh's cruelty, you set out with a heart filled with vengeance and a band of courageous warriors. These men, with eyes ablaze with the fire of revenge, stand ready to fight against Pharaoh's army in the vast expanses of the desert and ensure justice for their people. However, our numbers are still insufficient. We need 20 people. In this journey where courage, cunning, and strength come together, you will face every hardship to challenge Pharaoh's power");
        Thread.Sleep(5000); // 5 saniye bekler
        Console.WriteLine("\nPress any key to continue");
        Console.ReadKey();
    }

    static void InitializeMap()
    {
        // Haritayı boş karakterlerle dolduralım
        for (int y = 0; y < mapHeight; y++)
        {
            for (int x = 0; x < mapWidth; x++)
            {
                map[y, x] = '.';
            }
        }

        // Kervanın başlangıç pozisyonunu belirleyelim
        caravanX = mapWidth / 2;
        caravanY = mapHeight / 2;
        map[caravanY, caravanX] = 'C';

        // Örnek kervan yerleşkeleri ekleyelim
        AddCaravanSettlement(10, 10, "Oasis");
        AddCaravanSettlement(30, 20, "Desert Camp");
        AddCaravanSettlement(5, 5, "Nomad Camp");
        AddCaravanSettlement(25, 15, "Trading Post");
        // Add more settlements as needed
    }

    static void PlayGame()
    {
        while (true)
        {
            Console.Clear();
            DisplayMap();
            HandleInput();
            MoveEnemies();
            SpawnEnemies();

            // Asker sayısını kontrol et
            if (soldiers >= 20)
            {
                Console.WriteLine("              />\r\n (           //------------------------------------------------------(\r\n(*)OXOXOXOXO(*>                  Victory                             \\\r\n (           \\\\--------------------------------------------------------)\r\n              \\>");
                Console.WriteLine("Congratulations! You have gathered enough soldiers and concured the Pyramids!");
                Console.WriteLine("Press any key to exit.");
                Console.ReadKey();
                Environment.Exit(0); // Oyundan çık
            }
        }
    }


    static void DisplayMap()
    {
        for (int y = 0; y < mapHeight; y++)
        {
            for (int x = 0; x < mapWidth; x++)
            {
                if (map[y, x] == 'E')
                {
                    if (IsDaytime()) // Check if it's daytime
                    {
                        Console.ForegroundColor = ConsoleColor.Green; // Change color to green
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red; // Red for nighttime
                    }
                    Console.Write(map[y, x]);
                    Console.ResetColor();
                }
                else if (map[y, x] == 'R')
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write(map[y, x]);
                    Console.ResetColor();
                }
                else if (map[y, x] == '.')
                {
                    if (!IsDaytime())
                    {
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.Write(map[y, x]);
                        Console.ResetColor();
                    }
                    else
                    {
                        Console.Write(map[y, x]);
                    }
                }
                else
                {
                    Console.Write(map[y, x]);
                }
            }
            Console.WriteLine();
        }

        // Display HUD
        Console.WriteLine("**************************************************");
        Console.WriteLine($"Money: {money} | Soldiers: {soldiers} | Time: {hours:D2}:{minutes:D2} | {(IsDaytime() ? "Day" : "Night")}");
        // Display nearby settlements
        Console.Write("Nearby: ");
        DisplayNearbySettlements(caravanX, caravanY);
        Console.WriteLine();
        Console.WriteLine("*************************************************");
    }

    static void DisplayNearbySettlements(int caravanX, int caravanY)
    {
        // Define the radius for considering settlements as nearby (you can adjust this)
        int radius = 5;

        // Iterate over the map to find nearby settlements
        for (int y = Math.Max(0, caravanY - radius); y <= Math.Min(mapHeight - 1, caravanY + radius); y++)
        {
            for (int x = Math.Max(0, caravanX - radius); x <= Math.Min(mapWidth - 1, caravanX + radius); x++)
            {
                if (map[y, x] == '#') // Check if the tile contains a settlement
                {
                    // Calculate the distance between the caravan and the settlement
                    int distance = Math.Abs(caravanX - x) + Math.Abs(caravanY - y);
                    if (distance <= radius && !(x == caravanX && y == caravanY))
                    {
                        // Display the name of the nearby settlement
                        Console.Write($"{GetSettlementName(x, y)} ");
                    }
                }
            }
        }
    }

    static string GetSettlementName(int x, int y)
    {
        // Implement your logic to retrieve the name of the settlement at position (x, y)
        // For now, let's return a placeholder name
        return "Settlement";
    }


    static void HandleInput()
    {
        ConsoleKeyInfo keyInfo = Console.ReadKey(true);
        int newX = caravanX;
        int newY = caravanY;

        switch (keyInfo.Key)
        {
            case ConsoleKey.W:
                if (caravanY > 0) newY--;
                break;
            case ConsoleKey.S:
                if (caravanY < mapHeight - 1) newY++;
                break;
            case ConsoleKey.A:
                if (caravanX > 0) newX--;
                break;
            case ConsoleKey.D:
                if (caravanX < mapWidth - 1) newX++;
                break;
        }

        if (map[newY, newX] == '#') // Eğer yeni pozisyonda bir yerleşke varsa
        {
            ShowSettlementOptions(newX, newY);
        }
        else if (map[newY, newX] == 'E' || map[newY, newX] == 'R') // Eğer yeni pozisyonda bir düşman varsa
        {
            CombatScreen(newX, newY);
        }

        map[caravanY, caravanX] = '.';
        caravanX = newX;
        caravanY = newY;
        map[caravanY, caravanX] = 'C';

        // Zamanı 10 dakika ilerletelim
        AdvanceTime(10);
    }

    static void AddCaravanSettlement(int startX, int startY, string name)
    {
        // Yerleşke boyutu 1x1 olarak ayarlayalım
        if (startX < mapWidth && startY < mapHeight)
        {
            map[startY, startX] = '#';
        }
        // Yerleşke isimlerini saklayabilir veya başka yerleşke detayları ekleyebiliriz.
    }

    static void ShowSettlementOptions(int x, int y)
    {
        Console.Clear();
        Console.WriteLine($"You have arrived at a caravan settlement at ({x}, {y})!");
        Console.WriteLine("Choose who to talk to:");

        // Diyalog karakterleri
        Console.WriteLine("1. Talk to the Leader");
        Console.WriteLine("2. Talk to the Merchant");
        Console.WriteLine("3. Talk to the Innkeeper");

        string choice = "";
        while (true)
        {
            Console.Write("Enter your choice (1-3): ");
            choice = Console.ReadLine();

            if (choice == "1" || choice == "2" || choice == "3")
            {
                break;
            }
            else
            {
                Console.WriteLine("Invalid choice. Please enter a valid number (1-3).");
            }
        }

        switch (choice)
        {
            case "1":
                TalkToLeader();
                break;
            case "2":
                TalkToMerchant();
                break;
            case "3":
                TalkToInnkeeper();
                break;
        }

        Console.WriteLine("Press any key to return to the map.");
        Console.ReadKey(true);
    }

    static void TalkToLeader()
    {
        string fileName = @"..\..\TravelerName.txt";
        Console.WriteLine("Leader: Ah, a traveler seeking adventure!I think i know you.");

        StreamReader streamReader = new StreamReader(fileName);
        using (streamReader)
        {
            string fileContents = streamReader.ReadToEnd();
            Console.WriteLine(fileContents);
        }

        StreamReader reader = new StreamReader(fileName);
        using (reader)
        {
            int lineNumber = 0;
            string line = reader.ReadLine();
            while (line != null)
            {
                lineNumber++;
                Console.WriteLine("line {0}: {1}", lineNumber, line);
                Console.WriteLine("Right?");
                line = reader.ReadLine();
            }

        }
        Console.WriteLine("1. I seek a noble quest to prove my valor!");
        Console.WriteLine("2. Tell me, what rumors swirl about these lands?");
        Console.WriteLine("3. Very well, perhaps another time.");

        string choice = Console.ReadLine();
        switch (choice)
        {
            case "1":
                Console.WriteLine("Leader: A noble quest, you say? We have just the task for one as brave as you.");
                Console.WriteLine("1. Accept the quest.");
                Console.WriteLine("2. Decline the quest.");
                string questChoice = Console.ReadLine();
                if (questChoice == "1")
                {
                    // Quest kabul edildi, statları güncelle
                    money += 200;
                    soldiers += 2;
                    AdvanceTime(30);
                    Console.WriteLine("Leader: Excellent! Here are your rewards.");
                }
                else if (questChoice == "2")
                {
                    Console.WriteLine("Leader: No worries, perhaps another time then.");
                }
                break;
            case "2":
                Console.WriteLine("Leader: Ah, the rumors... Some speak of treasure hidden in the desert ruins.");
                Console.WriteLine("1. Investigate the ruins.");
                Console.WriteLine("2. Disregard the rumors.");
                string rumorChoice = Console.ReadLine();
                if (rumorChoice == "1")
                {
                    // Hazine aramaya karar verildi, statları güncelle
                    money -= 100;
                    soldiers -= 1;
                    AdvanceTime(60);
                    Console.WriteLine("Leader: Good luck on your expedition!");
                }
                else if (rumorChoice == "2")
                {
                    Console.WriteLine("Leader: Suit yourself, adventurer.");
                }
                break;
            case "3":
                Console.WriteLine("Leader: Farewell, traveler. May your journey be safe.");
                break;
        }
    }

    static void TalkToMerchant()
    {
        Console.WriteLine("Merchant: Welcome, welcome! Looking for wares to aid you on your journey?");
        Console.WriteLine("Let's talk shop:");
        Console.WriteLine("1. Show me your finest goods, merchant.");
        Console.WriteLine("2. I've got some wares of my own to sell.");
        Console.WriteLine("3. Perhaps later, my coin purse is feeling light.");

        string choice = Console.ReadLine();
        switch (choice)
        {
            case "1":
                Console.WriteLine("Merchant: Of course, have a look at my finest wares.");
                Console.WriteLine("1. Purchase items.");
                Console.WriteLine("2. Leave.");
                string purchaseChoice = Console.ReadLine();
                if (purchaseChoice == "1")
                {
                    // Eşya satın alındı, statları güncelle
                    money -= 150;
                    soldiers += 1;
                    AdvanceTime(15);
                    Console.WriteLine("Merchant: A pleasure doing business with you!");
                }
                else if (purchaseChoice == "2")
                {
                    Console.WriteLine("Merchant: Farewell, traveler.");
                }
                break;
            case "2":
                Console.WriteLine("Merchant: Ah, looking to sell? Let's see what you've got.");
                Console.WriteLine("1. Sell items.");
                Console.WriteLine("2. Keep your wares.");
                string sellChoice = Console.ReadLine();
                if (sellChoice == "1")
                {
                    // Eşya satıldı, statları güncelle
                    money += 100;
                    AdvanceTime(10);
                    Console.WriteLine("Merchant: Thank you for your business!");
                }
                else if (sellChoice == "2")
                {
                    Console.WriteLine("Merchant: Fair enough, perhaps another time.");
                }
                break;
            case "3":
                Console.WriteLine("Merchant: Come back anytime, traveler.");
                break;
        }
    }

    static void TalkToInnkeeper()
    {
        Console.WriteLine("Innkeeper: A weary traveler, seeking respite from the road?");
        Console.WriteLine("How can I be of service?");
        Console.WriteLine("1. A room for the night, please. I need to rest.");
        Console.WriteLine("2. Just a moment's respite by the fire, if you please.");
        Console.WriteLine("3. On second thought, I'll continue on my journey.");

        string choice = Console.ReadLine();
        switch (choice)
        {
            case "1":
                Console.WriteLine("Innkeeper: Of course, let me prepare a room for you.");
                Console.WriteLine("1. Rent a room.");
                Console.WriteLine("2. Leave.");
                string roomChoice = Console.ReadLine();
                if (roomChoice == "1")
                {
                    // Oda kiralandı, statları güncelle
                    money -= 50;
                    AdvanceTime(45);
                    Console.WriteLine("Innkeeper: Here's your key. Rest well!");
                }
                else if (roomChoice == "2")
                {
                    Console.WriteLine("Innkeeper: Safe travels, friend.");
                }
                break;
            case "2":
                Console.WriteLine("Innkeeper: Just a moment's respite? Of course, take a seat by the fire.");
                AdvanceTime(20);
                Console.WriteLine("Innkeeper: Enjoy your rest!");
                break;
            case "3":
                Console.WriteLine("Innkeeper: Farewell then, may the road be kind to you.");
                break;
        }
    }


    static void CombatScreen(int x, int y)
    {
        Console.Clear();
        Console.WriteLine($"You have encountered an enemy at ({x}, {y})!");
        Console.WriteLine("Prepare for battle!");

        // Example combat resolution
        if (soldiers > 0)
        {
            soldiers -= 1;
            if (IsDaytime())
            {
                soldiers += 2; // Gain 2 soldiers if it's daytime
                Console.WriteLine("You have defeated the enemy and gained 2 soldiers!");
            }
            else
            {
                Console.WriteLine("You have defeated the enemy but lost 1 soldier.");
            }
        }
        else
        {
            Console.WriteLine("You have no soldiers left to fight. Game over.");
            Environment.Exit(0);
        }

        // Remove the enemy from the map
        map[y, x] = '.';
        enemies.Remove((x, y));

        Console.WriteLine("Press any key to return to the map.");
        Console.ReadKey(true);
    }


    static void AdvanceTime(int minutesToAdd)
    {
        minutes += minutesToAdd;
        if (minutes >= 60)
        {
            hours += minutes / 60;
            minutes %= 60;
        }
        if (hours >= 24)
        {
            hours %= 24;
        }
    }

    static bool IsDaytime()
    {
        return hours >= 6 && hours < 18;
    }

    static void SpawnEnemies()
    {
        // Eğer geceyse ve aktif düşman sayısı 4'ten azsa yeni düşman spawn et
        if (!IsDaytime() && enemies.Count < 4)
        {
            Random rand = new Random();
            int enemyX, enemyY;
            do
            {
                enemyX = rand.Next(mapWidth);
                enemyY = rand.Next(mapHeight);
            } while (map[enemyY, enemyX] != '.');

            map[enemyY, enemyX] = 'R'; // Red enemy for night time
            enemies.Add((enemyX, enemyY));
        }
    }

    static void MoveEnemies()
    {
        Random rand = new Random();
        List<(int x, int y)> newPositions = new List<(int x, int y)>();

        foreach (var enemy in enemies)
        {
            int newX = enemy.x;
            int newY = enemy.y;

            if (!IsDaytime())
            {
                // Move towards the caravan at night
                if (caravanX > enemy.x && newX < mapWidth - 1)
                {
                    newX++;
                }
                else if (caravanX < enemy.x && newX > 0)
                {
                    newX--;
                }

                if (caravanY > enemy.y && newY < mapHeight - 1)
                {
                    newY++;
                }
                else if (caravanY < enemy.y && newY > 0)
                {
                    newY--;
                }
            }
            else
            {
                // Move randomly during the day
                switch (rand.Next(4))
                {
                    case 0:
                        if (newY > 0) newY--;
                        break;
                    case 1:
                        if (newY < mapHeight - 1) newY++;
                        break;
                    case 2:
                        if (newX > 0) newX--;
                        break;
                    case 3:
                        if (newX < mapWidth - 1) newX++;
                        break;
                }
            }

            if (map[newY, newX] == '.')
            {
                map[enemy.y, enemy.x] = '.';
                map[newY, newX] = IsDaytime() ? 'E' : 'R';
                newPositions.Add((newX, newY));
            }
            else
            {
                newPositions.Add(enemy);
            }
        }

        enemies = newPositions;
    }
}
